/*
	Defines the allowed tags */

#define ID0 "90fb78a2"
#define ID1 "3ea882b9" //3ea882b9
#define ID2 "00000000"
#define ID3 "00000000"
#define ID4 "00000000"
#define ID5 "00000000"
#define ID6 "00000000"
